package com.miscot.springmvc.service;

import com.miscot.springmvc.configuration.PropertiesPath;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.AlgorithmParameters;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.Security;
import java.security.cert.CertificateException;
import java.security.spec.InvalidParameterSpecException;
import java.util.Arrays;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SealedObject;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
@Service
public class CipherAESDemo implements CipherAESDemoInterface{

  // Configure these as required.
  
  private static final String passwd = "userpin";
  public static final String provider = "LunaProvider";
  public static final String keystoreProvider = "Luna";
  public static SealedObject so = null;
  
  private static final int slot = 0;
  //public static LunaSlotManager hsmConnection = null;
  public static String tokenLabel = "sidbi1"; //= "esignaturePartitionName";
  public static String password = "P@ssw0rd"; //= "esignaturePartitionPassword";
  @Autowired
	 PropertiesPath propertyPath;
  
  
  
  
  public  String encryptHsnData(String adhar_no) throws Exception {
	  	String pkcs11Config = propertyPath.getPkcs11Config();
	 	ByteArrayInputStream confStream = new ByteArrayInputStream(pkcs11Config.getBytes());
	    Provider prov = new sun.security.pkcs11.SunPKCS11(confStream);
	    Security.addProvider(prov);
	    KeyStore cc = null;
	    String pin =propertyPath.getPin(); // "PNBUSER1";
	    byte encrppteddata[] = null;
	    try {
	        cc = KeyStore.getInstance(propertyPath.getKeyStore(),prov);
	        KeyStore.PasswordProtection pp = new KeyStore.PasswordProtection(pin.toCharArray());
	        cc.load(null ,  pp.getPassword() );
   	             Key encryptionKey1 =  cc.getKey(propertyPath.getKey(), pin.toCharArray());
	        		 Cipher encryptCipher = null;
	        		 encryptCipher = Cipher.getInstance(propertyPath.getPaddingtype(), prov);
	        		 byte[] encryptInitializationVector = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 ,12,13,14,15};
	                 IvParameterSpec IV = new IvParameterSpec(encryptInitializationVector);
	                 encryptCipher.init(Cipher.ENCRYPT_MODE, encryptionKey1, IV);
	                 byte[] rawData = adhar_no.getBytes("UTF8");
	                 encrppteddata=encryptCipher.doFinal(rawData);
	    }    		
	    catch (Exception e) {
	        e.printStackTrace();
	    }
	    return  new BASE64Encoder().encode(encrppteddata); 
  }
  
  public String decryptHsnData(byte[] encryptedBytes) throws Exception
  {
	  String pkcs11Config =propertyPath.getPkcs11Config();// "name = SmartCard\nlibrary=C:/Windows/SysWOW64/cryptosec.dll";
	  ByteArrayInputStream confStream = new ByteArrayInputStream(pkcs11Config.getBytes());
	    Provider prov = new sun.security.pkcs11.SunPKCS11(confStream);
	    byte[] cipherText = null;
	    System.out.println("decryptHsnData");
	    Security.addProvider(prov);
	    KeyStore cc = null;
	    String pin = propertyPath.getPin();
	    try {
	        cc = KeyStore.getInstance(propertyPath.getKeyStore(),prov);
	        KeyStore.PasswordProtection pp = new KeyStore.PasswordProtection(pin.toCharArray());
	        cc.load(null ,  pp.getPassword() );
	             Key encryptionKey1 =  cc.getKey(propertyPath.getKey(), pin.toCharArray());
   		 Cipher encryptCipher = null;
   		 encryptCipher = Cipher.getInstance(propertyPath.getPaddingtype(), prov);
   		 byte[] encryptInitializationVector = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 ,12,13,14,15};
            IvParameterSpec IV = new IvParameterSpec(encryptInitializationVector);
	  		byte encryptedText[] =encryptedBytes;
	   encryptCipher.init(Cipher.DECRYPT_MODE, encryptionKey1, IV);
                 cipherText = encryptCipher.doFinal(encryptedText);
        }    		
		catch (Exception e) {
	        e.printStackTrace();
	    }
	    return  new String(cipherText); 
  }
  
  
  public  String encryptHsnData1(String adhar_no) throws Exception {
	 
	  System.out.println("Inside encryption======++++++");
    KeyStore myStore = null;
    byte[] encryptedbytes = null;
    try
    {

      /*
        Note: could also use a keystore file, which contains the token label or slot no. to use.
        Load that via "new FileInputStream(ksFileName)" instead of ByteArrayInputStream. Save
        objects to the keystore via a FileOutputStream.
       */
     System.out.println("Inside encryptHsnData");
      ByteArrayInputStream is1 = new ByteArrayInputStream(("slot:" + slot).getBytes());
      myStore = KeyStore.getInstance(keystoreProvider);
      myStore.load(is1, passwd.toCharArray());
      
      
      
    } catch (KeyStoreException kse) {
      System.out.println("Unable to create keystore object");
      System.exit(-1);
    } catch (NoSuchAlgorithmException nsae) {
      System.out.println("Unexpected NoSuchAlgorithmException while loading keystore");
      System.exit(-1);
    } catch (CertificateException e) {
      System.out.println("Unexpected CertificateException while loading keystore");
      System.exit(-1);
    } catch (IOException e) {
      // this should never happen
      System.out.println("Unexpected IOException while loading keystore.");
      System.exit(-1);
    }
    
    try {
      
      KeyGenerator.getInstance("AES", "LunaProvider");

      byte[] blockSizeData = new byte[1024];
      blockSizeData=adhar_no.getBytes();
     String ENCRYPTION_KEY = "0123456789abcdef";
      SecretKeySpec keys = new SecretKeySpec(ENCRYPTION_KEY.getBytes("UTF-8"), "AES");
      // get some new random data each time just to mix things up a bit
      

      Cipher encCipher = null;
      Cipher decCipher = null;
      byte[] iv = null;
      
      AlgorithmParameters lunaParams = null;
//      encCipher = Cipher.getInstance("AES/ECB/NoPadding", "LunaProvider");
//      encCipher = Cipher.getInstance("AES/CBC/NoPadding", "LunaProvider");
      encCipher = Cipher.getInstance("AES/CBC/PKCS5Padding", "LunaProvider");
//      encCipher = Cipher.getInstance("AES/CBC/ISO10126Padding", "LunaProvider");
//      encCipher = Cipher.getInstance("AES/CFB8/NoPadding", "LunaProvider");
//      encCipher = Cipher.getInstance("AES/CFB128/NoPadding", "LunaProvider");
//      encCipher = Cipher.getInstance("AES/OFB/NoPadding", "LunaProvider");
//      encCipher = Cipher.getInstance("AES/CTR/NoPadding", "LunaProvider");

//      decCipher = Cipher.getInstance("AES/ECB/NoPadding", "LunaProvider");
//      needParms = false;
//      decCipher = Cipher.getInstance("AES/CBC/NoPadding", "LunaProvider");
      decCipher = Cipher.getInstance("AES/CBC/PKCS5Padding", "LunaProvider");
//      decCipher = Cipher.getInstance("AES/CBC/ISO10126Padding", "LunaProvider");
//      decCipher = Cipher.getInstance("AES/CFB8/NoPadding", "LunaProvider");
//      decCipher = Cipher.getInstance("AES/CFB128/NoPadding", "LunaProvider");
//      decCipher = Cipher.getInstance("AES/OFB/NoPadding", "LunaProvider");
//      decCipher = Cipher.getInstance("AES/CTR/NoPadding", "LunaProvider");

      iv = encCipher.getIV();
      if (iv == null) {
          // is AES ok for any secret key?
        lunaParams = AlgorithmParameters.getInstance("AES", provider);
        IvParameterSpec IV16 = new IvParameterSpec(new byte[] { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
            0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x10, 0x11 });
        lunaParams.init(IV16);
      }
      //      encCipher.init(Cipher.ENCRYPT_MODE, key, dummyParams);
      encCipher.init(Cipher.ENCRYPT_MODE, keys, lunaParams);
      new IvParameterSpec(encCipher.getIV());
//      decCipher.init(Cipher.DECRYPT_MODE, key, ivps);
      decCipher.init(Cipher.DECRYPT_MODE, keys, lunaParams);
     
      System.out.println("Encrypting PlainText");
      encryptedbytes = encCipher.doFinal(blockSizeData);
      System.out.println("Encryption Data"+encryptedbytes);
      
  /* System.out.println("Decrypting to PlainText");
      byte[] decryptedbytes = null;
      decryptedbytes = decCipher.doFinal(encryptedbytes);
      Arrays.equals(decryptedbytes, encryptedbytes);
      System.out.println("Decryption Data"+new String(decryptedbytes));*/
      
    } catch (NoSuchAlgorithmException e) {
      
      e.printStackTrace();
    } catch (NoSuchProviderException e) {
      
      e.printStackTrace();
    } catch (NoSuchPaddingException e) {
      
      e.printStackTrace();
    } catch (InvalidKeyException e) {
      
      e.printStackTrace();
    } catch (IllegalBlockSizeException e) {
      
      e.printStackTrace();
    } catch (BadPaddingException e) {
      
      e.printStackTrace();
    } catch (InvalidAlgorithmParameterException e) {
      
      e.printStackTrace();
    } catch (InvalidParameterSpecException e) {
      
      e.printStackTrace();
    }
    return  new BASE64Encoder().encode(encryptedbytes); 
    
  }
  public  String decryptHsnData1(byte[] encryptedBytes) throws Exception
  {

	  System.out.println("Inside Decryption======++++++");
    KeyStore myStore = null;
 
    byte[] decryptedbytes = null;
    try
    {

      /*
        Note: could also use a keystore file, which contains the token label or slot no. to use.
        Load that via "new FileInputStream(ksFileName)" instead of ByteArrayInputStream. Save
        objects to the keystore via a FileOutputStream.
       */
System.out.println("Inside decryptHsnData");
      ByteArrayInputStream is1 = new ByteArrayInputStream(("slot:" + slot).getBytes());
      myStore = KeyStore.getInstance(keystoreProvider);
      myStore.load(is1, passwd.toCharArray());
    } catch (KeyStoreException kse) {
      System.out.println("Unable to create keystore object");
      System.exit(-1);
    } catch (NoSuchAlgorithmException nsae) {
      System.out.println("Unexpected NoSuchAlgorithmException while loading keystore");
      System.exit(-1);
    } catch (CertificateException e) {
      System.out.println("Unexpected CertificateException while loading keystore");
      System.exit(-1);
    } catch (IOException e) {
      // this should never happen
      System.out.println("Unexpected IOException while loading keystore.");
      System.exit(-1);
    }
    
    try {
      
      KeyGenerator.getInstance("AES", "LunaProvider");

      "740004053909".getBytes();
     String ENCRYPTION_KEY = "0123456789abcdef";
      SecretKeySpec keys = new SecretKeySpec(ENCRYPTION_KEY.getBytes("UTF-8"), "AES");
      // get some new random data each time just to mix things up a bit
      

      Cipher encCipher = null;
      Cipher decCipher = null;
      byte[] iv = null;
      
      AlgorithmParameters lunaParams = null;
//      encCipher = Cipher.getInstance("AES/ECB/NoPadding", "LunaProvider");
//      encCipher = Cipher.getInstance("AES/CBC/NoPadding", "LunaProvider");
      encCipher = Cipher.getInstance("AES/CBC/PKCS5Padding", "LunaProvider");
//      encCipher = Cipher.getInstance("AES/CBC/ISO10126Padding", "LunaProvider");
//      encCipher = Cipher.getInstance("AES/CFB8/NoPadding", "LunaProvider");
//      encCipher = Cipher.getInstance("AES/CFB128/NoPadding", "LunaProvider");
//      encCipher = Cipher.getInstance("AES/OFB/NoPadding", "LunaProvider");
//      encCipher = Cipher.getInstance("AES/CTR/NoPadding", "LunaProvider");

//      decCipher = Cipher.getInstance("AES/ECB/NoPadding", "LunaProvider");
//      needParms = false;
//      decCipher = Cipher.getInstance("AES/CBC/NoPadding", "LunaProvider");
      decCipher = Cipher.getInstance("AES/CBC/PKCS5Padding", "LunaProvider");
//      decCipher = Cipher.getInstance("AES/CBC/ISO10126Padding", "LunaProvider");
//      decCipher = Cipher.getInstance("AES/CFB8/NoPadding", "LunaProvider");
//      decCipher = Cipher.getInstance("AES/CFB128/NoPadding", "LunaProvider");
//      decCipher = Cipher.getInstance("AES/OFB/NoPadding", "LunaProvider");
//      decCipher = Cipher.getInstance("AES/CTR/NoPadding", "LunaProvider");

      iv = encCipher.getIV();
      if (iv == null) {
          // is AES ok for any secret key?
        lunaParams = AlgorithmParameters.getInstance("AES", provider);
        IvParameterSpec IV16 = new IvParameterSpec(new byte[] { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
            0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x10, 0x11 });
        lunaParams.init(IV16);
      }
   
     
      decCipher.init(Cipher.DECRYPT_MODE, keys, lunaParams);
     
  
      
   System.out.println("Decrypting to PlainText");
   
      decryptedbytes = decCipher.doFinal(encryptedBytes);
      Arrays.equals(decryptedbytes, encryptedBytes);
      System.out.println("Decryption Data"+new String(decryptedbytes));
      
    } catch (NoSuchAlgorithmException e) {
      
      e.printStackTrace();
    } catch (NoSuchProviderException e) {
      
      e.printStackTrace();
    } catch (NoSuchPaddingException e) {
      
      e.printStackTrace();
    } catch (InvalidKeyException e) {
      
      e.printStackTrace();
    } catch (IllegalBlockSizeException e) {
      
      e.printStackTrace();
    } catch (BadPaddingException e) {
      
      e.printStackTrace();
    } catch (InvalidAlgorithmParameterException e) {
      
      e.printStackTrace();
    } catch (InvalidParameterSpecException e) {
      
      e.printStackTrace();
    }
    return  new String(decryptedbytes); 

	  
  }
 /*public static void main(String a[])
  {
	  try {
		String data=encryptBlowFish11111("896666666669");
		System.out.println("Data"+data);
	} catch (Exception e) {
		
		e.printStackTrace();
	}
  }

  public static String encryptBlowFish11111(String strClearText) throws Exception{
		String strData="";
		String pass="Miscot";
		try {
			SecretKeySpec skeyspec=new SecretKeySpec(pass.getBytes(),"Blowfish");
			Cipher cipher=Cipher.getInstance("Blowfish");
			cipher.init(Cipher.ENCRYPT_MODE, skeyspec);
			byte[] encrypted=cipher.doFinal(strClearText.getBytes("UTF-8"));
			strData = new BASE64Encoder().encode(encrypted);
			//strData=new String(encrypted);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e);
		}
		return strData;
	}*/
  
  public  String encryptBlowFish(String strClearText) throws Exception{
		String strData="";
		String pass="Miscot";
		try {
			SecretKeySpec skeyspec=new SecretKeySpec(pass.getBytes(),"Blowfish");
			Cipher cipher=Cipher.getInstance("Blowfish");
			cipher.init(Cipher.ENCRYPT_MODE, skeyspec);
			byte[] encrypted=cipher.doFinal(strClearText.getBytes("UTF-8"));
			strData = new BASE64Encoder().encode(encrypted);
			//strData=new String(encrypted);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e);
		}
		return strData;
	}
	public  String decryptBlowFish(String strEncrypted) throws Exception{
		String strData="";
		String pass="Miscot";
		try {
			//System.out.println("strEncrypted"+strEncrypted);
			byte[] output = new BASE64Decoder().decodeBuffer(strEncrypted);
			SecretKeySpec skeyspec=new SecretKeySpec(pass.getBytes(), "Blowfish");
			Cipher cipher=Cipher.getInstance("Blowfish");
			cipher.init(Cipher.DECRYPT_MODE, skeyspec);
			byte[] decrypted=cipher.doFinal(output);
			strData=new String(decrypted);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e);
		}
		return strData;
	}




}


