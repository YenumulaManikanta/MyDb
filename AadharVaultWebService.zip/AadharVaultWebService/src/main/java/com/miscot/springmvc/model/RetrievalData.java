package com.miscot.springmvc.model;

import org.springframework.stereotype.Component;

@Component
public class RetrievalData {
	
/*	<RTREQ  TS="">
	<PASSWORD>ABC</PASSWORD>
	<REQREF>123456789012</<REQREF>
	<REFTYPE>A</<REFTYPE>
	<APPUSER>20001</APPUSER>
	</STORE>*/
	public String Password;
	public String Aadharno;
	public String APPUSER;
	public String REQREF;
	public String REFTYPE;
	public String TS;
    public String Status=null;


public String getPassword() {
	return Password;
}
public void setPassword(String password) {
	Password = password;
}
public String getAadharno() {
	return Aadharno;
}
public void setAadharno(String aadharno) {
	Aadharno = aadharno;
}
public String getAPPUSER() {
	return APPUSER;
}
public void setAPPUSER(String aPPUSER) {
	APPUSER = aPPUSER;
}
public String getTS() {
	return TS;
}
public void setTS(String tS) {
	TS = tS;
}
public String getStatus() {
	return Status;
}
public void setStatus(String status) {
	Status = status;
}
public String getREQREF() {
	return REQREF;
}
public void setREQREF(String rEQREF) {
	REQREF = rEQREF;
}
public String getREFTYPE() {
	return REFTYPE;
}
public void setREFTYPE(String rEFTYPE) {
	REFTYPE = rEFTYPE;
}

}
