package com.miscot.springmvc.repository;

import com.miscot.springmvc.dao.AppUser;

public interface DBUtilInterface {
AppUser validateUserData(final String userid,final String LK,final String RemoteIP);
String retrieveUid(String encAdhNo);
String getSingleValues(String query);
String RemoveNull(String Val) throws Exception;
int updateDashBoard(String userid);
String retrieveSequence();
int insertTblVault(String string, String userid, String ipAdd, String encAdhNo, String uuid);

String retreieveAadhar(String string);
int searchInsertActivityLog(String userid, String string, String time, String ipAdd, String msg,
		String rEQREF, String appuser, String txn, String rETCODE, String rETM) throws Exception;
int retrieveUpdateAadhar(String userid);
}
