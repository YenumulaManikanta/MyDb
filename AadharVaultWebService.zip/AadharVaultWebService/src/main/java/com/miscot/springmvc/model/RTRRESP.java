package com.miscot.springmvc.model;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;
@Component
@XmlRootElement(name = "rtresp")
@XmlAccessorType(XmlAccessType.FIELD)
public class RTRRESP {
	@XmlAttribute
	 String ts;
	@XmlElement
	 String refno;
	@XmlElement
	 String reftype;
	@XmlElement
	 String aadharno;
	
	public String getTS() {
		return ts;
	}
	public void setTS(String tS) {
		ts = tS;
	}
	public String getREFNO() {
		return refno;
	}
	public void setREFNO(String rEFNO) {
		refno = rEFNO;
	}
	public String getREFTYPE() {
		return reftype;
	}
	public void setREFTYPE(String rEFTYPE) {
		reftype = rEFTYPE;
	}
	public String getAADHARNO() {
		return aadharno;
	}
	public void setAADHARNO(String aADHARNO) {
		aadharno = aADHARNO;
	}

	
	
	
}
