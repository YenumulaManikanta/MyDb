package com.miscot.springmvc.model;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;
@Component
@XmlRootElement(name="Auth")

@XmlAccessorType(XmlAccessType.FIELD)
public class AUTH {
	@XmlAttribute(name="userid")
	  public String userid;
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String Userid) {
		userid = Userid;
	}
	public String getLK() {
		return lk;
	}
	public void setLK(String lK) {
		lk = lK;
	}
	public String getTXN() {
		return txn;
	}
	public void setTXN(String tXN) {
		txn = tXN;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String Version) {
		version = Version;
	}
	public String getTS() {
		return ts;
	}
	public void setTS(String tS) {
		ts = tS;
	}
	@XmlAttribute(name="lk")
	public
	 String lk;
	@XmlAttribute(name="txn")
	public  String txn;
	@XmlAttribute(name="ver")
	public String version;
	@XmlAttribute(name="ts")
	public String ts;
}