package com.miscot.springmvc.model;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;
@Component
@XmlRootElement(name = "strresp")
public class STRRESP {
	@XmlAttribute(name="ts")
	 public String ts;
	@XmlElement(name="refno")
	 public String refno;



}
