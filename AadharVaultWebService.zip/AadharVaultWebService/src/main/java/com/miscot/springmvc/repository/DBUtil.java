package com.miscot.springmvc.repository;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Properties;
import java.util.Vector;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;

import org.springframework.stereotype.Repository;

import com.miscot.springmvc.dao.AppUser;

@Repository
public class DBUtil implements DBUtilInterface {
	
	public Connection conn = null;
	static String ConnectionStatus = "N";
	static String LastError = "";
	public static String ip_addr = "";
	@Autowired
    JdbcTemplate jdbcTemplate;

	public String GetValue(String sql) throws SQLException, Exception {
		//System.out.println("GetValue " + sql);
		String Res = "";
		PreparedStatement prepStmt = null;
		ResultSet rs = null;

		try {

			prepStmt = conn.prepareStatement(sql);
			rs = prepStmt.executeQuery();
			if (rs != null) {
				while (rs.next()) {
					Res = RemoveNull(rs.getString(1));
				}
			}
		}

		catch (SQLException ex) {
			ex.printStackTrace();
		}

		finally {
			prepStmt.close();
			rs.close();
		}

		return Res;
	}

	public AppUser validateUserData(final String userid, final String licenseKey, final String RemoteIP) {
		final String query = "SELECT USER_ID,LICENCE_KEY,IP_ADDTRESS,Password1,pub_cert_path ,APPLICATION_NAME from tbl_app_user WHERE USER_ID= ? and USER_STATUS='E'";
		final AppUser appUser = new AppUser();
		try {
			return (AppUser) jdbcTemplate.query(query, new Object[] { userid }, new ResultSetExtractor<AppUser>() {
				public AppUser extractData(ResultSet rs) throws SQLException, DataAccessException {
					String Status = null;
					if (rs.next()) {
						if (!(rs.getString("LICENCE_KEY").equals(licenseKey))) {
							Status = "05~" + rs.getString("USER_ID") + "~" + rs.getString("Password1") + "~"
									+ rs.getString("pub_cert_path") + "~" + rs.getString("APPLICATION_NAME");
						}

						else if (!(rs.getString("IP_ADDTRESS").equals(RemoteIP))) {
							Status = "10~" + rs.getString("USER_ID") + "~" + rs.getString("Password1") + "~"
									+ rs.getString("pub_cert_path") + "~" + rs.getString("APPLICATION_NAME");
						} else {
							Status = "00~" + rs.getString("USER_ID") + "~" + rs.getString("Password1") + "~"
									+ rs.getString("pub_cert_path") + "~" + rs.getString("APPLICATION_NAME");
						}

					}

					else {
						Status = "04~" + userid + "~" + Character.toString((char) 32) + "~"
								+ Character.toString((char) 32) + "~" + Character.toString((char) 32);
					}
					appUser.setUser_Status(Status);
					return appUser;
				}
			});
		} catch (EmptyResultDataAccessException e) {
			// TODO Auto-generated catch block
			//System.out.println("Exception Occured" + e.getMessage());
			e.printStackTrace();
		}
		return appUser;

	}

	public String retrieveUid(String encAdhNo) {
		// TODO Auto-generated method stub
		String query = "select uuid from tbl_vault where encAdhNo='" + encAdhNo + "'";
		String result = getSingleValues(query);
		//System.out.println("Result is" + result);
		return result;
	}

	public String getSingleValues(final String query) {
		// TODO Auto-generated method stub

		return (String) jdbcTemplate.query(query, new Object[] {}, new ResultSetExtractor<String>() {

			public String extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				String Status = null;
				String Res = "";
				//System.out.println("Query" + query + "rs" + rs);
				// //System.out.println("rs.next()"+rs.next()+rs.getString("USER_ID"));

				if (rs != null) {
					while (rs.next()) {
						try {
							Res = RemoveNull(rs.getString(1));
							return Res;
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}

				// set other properties

				return Res;
			}
		});

	}

	public int updateOrInsertValues(String query) {
		int i = jdbcTemplate.update(query);
		return i;
	}

	public int updateDashBoard(String userid) {
		// TODO Auto-generated method stub
		String query = "update tbl_dashboard set FIELD_VALUE = FIELD_VALUE + 1 where CHART_ID = 2  and FIELD_NAME='"
				+ userid + "'";
		int result = updateOrInsertValues(query);
		return result;
	}

	public int insertActivityLog(String userid, String string, String time, String ipAdd, String msg, String string2,
			String string3, String string4, String string5, String string6) {
		// TODO Auto-generated method stub
		String query = "INSERT INTO ActivityLog(USER_ID,APPNAME,DATE_D,TIME_T,IP_ADDRESS,TASK_PERFORMED,DESCPTION,uuid,app_user,txn,Error_code,Error_Rem)     "
				+ "VALUES('" + userid + "','" + string + "',current_date,'" + time + "','" + ipAdd + "','Insert','" + msg
				+ "',null,'" + string3 + "','" + string4 + "','" + string5 + "','" + string6 + "')";
		int result = updateOrInsertValues(query);
		return result;
	}

	public String retrieveSequence() {
		// TODO Auto-generated method stub
		String query = "Select LPAD(to_char(seq_uuid.nextval),12,0) from dual";
		String result = getSingleValues(query);
		//System.out.println("Result is" + result);
		return result;

	}

	public int insertTblVault(String string, String userid, String ipAdd, String encAdhNo, String uuid,String partionID ) {
		// TODO Auto-generated method stub
		String query = "INSERT INTO tbl_vault(id,appname,user_id,date_time,ip_address,encAdhNo,uuid,ver_no,del_flg,PARTION_ID)"
				+ " VALUES(seq_id.nextval,'" + string + "','" + userid + "',current_date,'" + ipAdd + "','" + encAdhNo
				+ "','" + uuid + "','1.1','N','"+partionID+"')";
		int result = updateOrInsertValues(query);
		return result;
	}
	public String RemoveNull(String Val) throws Exception {
		String Res = "";
		if (Val == null) {
			Res = "";
		} else {
			Res = Val;
		}
		return Res;
	}

	public String retreieveAadhar(String uuid) {
		// TODO Auto-generated method stub
		String query = "select encAdhNo from tbl_vault where uuid='"+ uuid +"'";
		String result = getSingleValues(query);
		//System.out.println("Result is" + result);
		return result;
	}

	public int searchInsertActivityLog(String userid, String string, String time, String ipAdd, String msg,
			String rEQREF, String appuser, String txn, String rETCODE, String rETM) throws Exception {
		// TODO Auto-generated method stub
		String query = "INSERT INTO ActivityLog(USER_ID,APPNAME,DATE_D,TIME_T,IP_ADDRESS,TASK_PERFORMED,DESCPTION,uuid,app_user,txn,Error_code,Error_Rem)    "+
			"VALUES('"+userid+"','"+ string+"',current_date,'"+time+"','"+ipAdd+"','Search','"+ msg +"','"+rEQREF+"','"+RemoveNull(appuser)+"','"+txn+"','"+rETCODE+"','"+rETM+"')";
		int result = updateOrInsertValues(query);
		return result;
		
	}

	public int retrieveUpdateAadhar(String userid) {
		// TODO Auto-generated method stub
		String query = "update tbl_dashboard set FIELD_VALUE = FIELD_VALUE + 1 where CHART_ID = 3  and FIELD_NAME='"
				+ userid + "'";
		int result = updateOrInsertValues(query);
		return result;
	}

	public int insertTblVault(String string, String userid, String ipAdd, String encAdhNo, String uuid) {
		// TODO Auto-generated method stub
		return 0;
	}

	

}
