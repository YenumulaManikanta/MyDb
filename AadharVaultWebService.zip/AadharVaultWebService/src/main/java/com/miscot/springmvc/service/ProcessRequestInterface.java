package com.miscot.springmvc.service;

import org.bouncycastle.crypto.InvalidCipherTextException;

import com.miscot.springmvc.model.ADHRTREQ;
import com.miscot.springmvc.model.ADHRTRESP;
import com.miscot.springmvc.model.ADHSTREQ;
import com.miscot.springmvc.model.ADHSTRRESP;
import com.miscot.springmvc.model.DATA;
import com.miscot.springmvc.model.RetrievalData;
import com.miscot.springmvc.model.StoreData;
import com.miscot.springmvc.model.StoreReq;

public interface ProcessRequestInterface {
	
	ADHSTRRESP  StoreAadhar(String data, String ipAdd) throws Exception;
	String RemoveNull(String Val) throws Exception;
	StoreReq ParseStoreReq(String data);
	String ValidateUser(String userid, String LK, String RemoteIP);
	StoreData ParseDATAReq(String data);
	DATA getData(byte[] SessionKey,String TS, byte[] inputData) throws IllegalStateException, InvalidCipherTextException, Exception;
	RetrievalData ParseRetriavalDATAReq(String data);
	ADHRTRESP retriveAdhData(String data, String ipAdd)throws Exception;
	
}
