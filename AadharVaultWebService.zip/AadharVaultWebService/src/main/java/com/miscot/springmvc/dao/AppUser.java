package com.miscot.springmvc.dao;

public class AppUser {
private String User_Id;
private String Ip_Addtress;
private String Application_Name;
private String Licence_Key;
private String User_Status;
private String Pub_Cert_Path;
private String Password1;

public AppUser() {
	super();
	// TODO Auto-generated constructor stub
}

public AppUser(String user_Id, String ip_Addtress, String application_Name, String licence_Key, String user_Status,
		String pub_Cert_Path, String password1) {
	super();
	User_Id = user_Id;
	Ip_Addtress = ip_Addtress;
	Application_Name = application_Name;
	Licence_Key = licence_Key;
	User_Status = user_Status;
	Pub_Cert_Path = pub_Cert_Path;
	Password1 = password1;
}

@Override
public String toString() {
	return "AppUser [User_Id=" + User_Id + ", Ip_Addtress=" + Ip_Addtress + ", Application_Name=" + Application_Name
			+ ", Licence_Key=" + Licence_Key + ", User_Status=" + User_Status + ", Pub_Cert_Path=" + Pub_Cert_Path
			+ ", Password1=" + Password1 + "]";
}

public String getUser_Id() {
	return User_Id;
}

public void setUser_Id(String user_Id) {
	User_Id = user_Id;
}

public String getIp_Addtress() {
	return Ip_Addtress;
}

public void setIp_Addtress(String ip_Addtress) {
	Ip_Addtress = ip_Addtress;
}

public String getApplication_Name() {
	return Application_Name;
}

public void setApplication_Name(String application_Name) {
	Application_Name = application_Name;
}

public String getLicence_Key() {
	return Licence_Key;
}

public void setLicence_Key(String licence_Key) {
	Licence_Key = licence_Key;
}

public String getUser_Status() {
	return User_Status;
}

public void setUser_Status(String user_Status) {
	User_Status = user_Status;
}

public String getPub_Cert_Path() {
	return Pub_Cert_Path;
}

public void setPub_Cert_Path(String pub_Cert_Path) {
	Pub_Cert_Path = pub_Cert_Path;
}

public String getPassword1() {
	return Password1;
}

public void setPassword1(String password1) {
	Password1 = password1;
}


}
