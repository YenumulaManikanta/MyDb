package com.miscot.springmvc.model;

import org.springframework.stereotype.Service;

@Service
public class FirstService {
public String sayHello()
{
	return "Hello";
}
}
