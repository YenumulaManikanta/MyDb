package com.miscot.springmvc.model;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;
@Component
@XmlRootElement(name = "rtreq")
@XmlAccessorType(XmlAccessType.FIELD)
public class RTREQ {
	@XmlAttribute(name="ts")
	private String ts;
	@XmlElement
	private String password;
	@XmlElement
	private String reqref;
	@XmlElement
	private String aadharno;
	@XmlElement
	private String reftype;
	@XmlElement
	private String appuser;
	public String getTS() {
		return ts;
	}
	public void setTS(String tS) {
		ts = tS;
	}
	public String getPASSWORD() {
		return password;
	}
	public void setPASSWORD(String pASSWORD) {
		password = pASSWORD;
	}
	public String getREQREF() {
		return reqref;
	}
	public void setREQREF(String rEFNO) {
		reqref = rEFNO;
	}
	public String getREFTYPE() {
		return reftype;
	}
	public void setREFTYPE(String rEFTYPE) {
		reftype = rEFTYPE;
	}
	public String getAPPUSER() {
		return appuser;
	}
	public void setAPPUSER(String aPPUSER) {
		appuser = aPPUSER;
	}
	public String getAADHARNO() {
		return aadharno;
	}
	public void setAADHARNO(String aADHARNO) {
		aadharno = aADHARNO;
	}

	
	

}
