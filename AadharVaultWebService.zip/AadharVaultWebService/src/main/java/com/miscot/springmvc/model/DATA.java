package com.miscot.springmvc.model;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlValue;

//@XmlRootElement(name="Data")
@XmlAccessorType(XmlAccessType.FIELD )
public class DATA {
	
	 /*@XmlElement(name="STRRESP")
	 STRRESP strresp;
	 @XmlElement(name="RTRRESP")
	 RTRRESP rtrresp;

public STRRESP getStrresp() {
	return strresp;
}

public void setStrresp(STRRESP strresp) {
	this.strresp = strresp;
}*/

@XmlValue
public String innerText;
}

