package com.miscot.springmvc.service;

import java.io.StringReader;
import java.io.StringWriter;
import java.security.interfaces.RSAPrivateKey;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

//import org.apache.tomcat.util.codec.binary.Base64;
import org.apache.commons.codec.binary.Base64;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import sun.misc.BASE64Decoder;

import com.miscot.springmvc.configuration.PropertiesPath;
import com.miscot.springmvc.dao.AppUser;
import com.miscot.springmvc.model.ADHRTRESP;
//import com.miscot.springmvc.dao.AppUser;
//import com.miscot.bean.RetrievalData;
import com.miscot.springmvc.model.ADHSTRRESP;
import com.miscot.springmvc.model.DATA;
import com.miscot.springmvc.model.AUTH;
import com.miscot.springmvc.model.HMAC;
import com.miscot.springmvc.model.RTRRESP;
import com.miscot.springmvc.model.RetrievalData;
import com.miscot.springmvc.model.SKEY;
import com.miscot.springmvc.model.STRRESP;
import com.miscot.springmvc.model.StoreData;
import com.miscot.springmvc.model.StoreReq;
import com.miscot.springmvc.repository.DBUtil;
@Service
@Transactional

public class ProcessReqXML implements ProcessRequestInterface {
	@Autowired
	private ADHSTRRESP ADHSTRRESPobj;
	@Autowired
	private ADHRTRESP ADHRTRRESPobj;
	@Autowired
	private DBUtil db;
	@Autowired
	private StoreData  StoreDataobj;
	
	@Autowired
	private StoreReq StoreReqobj;
	@Autowired
	private AESCipher aesCipher;
	
	 @Autowired
	 private PropertiesPath propertyPath;
	 @Autowired
	 private CipherAESDemo cipherAesDemo;
	 @Autowired
	 private STRRESP strResp;
	 @Autowired
	 private RSA rsa;
	 @Autowired
	 private RTRRESP rtrResp;
	 @Autowired
	 private AUTH auth;
	 @Autowired
	 private RetrievalData RetrieveDataObj;

	public ADHSTRRESP StoreAadhar(String data, String ipAdd) throws Exception {
		String ValidateUserRespres[];
		String TEST = Character.toString((char) 32) + "~" + Character.toString((char) 32) + "~"
				+ Character.toString((char) 32) + "~" + Character.toString((char) 32) + "~"
				+ Character.toString((char) 32);
		ValidateUserRespres = TEST.split("~");
		String time = "";
		String uuid = "";
		String msg = " ";
		String refno1 = " ";
		try {
			time = new SimpleDateFormat("hh:mm:ss aa").format(new Date());
			ADHSTRRESPobj.retcode = "00";
			//System.out.println("reqXML123::::::::::::"+data);
			StoreReqobj = ParseStoreReq(data);
			System.out.println("data:::"+StoreReqobj.getTXN()+"::::"+StoreReqobj.getDATA());
			String ValidateUserResp = null;
			String decTxt = null;
			byte[] sessionKey = null;
			String CertPath = propertyPath.getCertPath();
			String ClientCertPath=propertyPath.getClientCertificateName();
			retrieveAAdharData();
			if (StoreReqobj.getStatus().equalsIgnoreCase("Y")) {
				ValidateUserResp = ValidateUser(StoreReqobj.userid, StoreReqobj.lk, ipAdd);
				ValidateUserRespres = ValidateUserResp.split("~");
				if (ValidateUserRespres[0].equalsIgnoreCase("00")) {
					auth.lk = StoreReqobj.lk;
					auth.txn = StoreReqobj.txn;
					auth.userid = StoreReqobj.userid;
					auth.version = StoreReqobj.ver;
					RSAPrivateKey privateKey = rsa.getPrivateKey(CertPath + "SWIFTDBVAULTPUBkey.pem");
					try {
						sessionKey = rsa.decrypt1(StoreReqobj.skey, privateKey);
					} catch (Exception e) {
						e.printStackTrace();
						ADHSTRRESPobj.retcode = "11";
						ADHSTRRESPobj.retm = "FAIL";
					}
					try {
						//System.out.println("arrive");
						decTxt = aesCipher.getDecrypted(Base64.decodeBase64(StoreReqobj.data), sessionKey,Base64.decodeBase64(StoreReqobj.hmac));
						System.out.println("decTxt::"+decTxt);
					} catch (Exception e) {
						e.printStackTrace();
						ADHSTRRESPobj.retcode = "12";
						ADHSTRRESPobj.retm = "FAIL";
					}
				} else {
					ADHSTRRESPobj.retcode = ValidateUserRespres[0];
					ADHSTRRESPobj.retm = "FAIL";
				}
			} else {
				ADHSTRRESPobj.retcode = "100";
				ADHSTRRESPobj.retm = "FAIL";
			}
			if (ADHSTRRESPobj.retcode.equalsIgnoreCase("00")) {
				StoreDataobj = ParseDATAReq(decTxt);
				if (StoreDataobj.getStatus().equalsIgnoreCase("Y")) {
					if (ValidateUserRespres[2].equals(StoreDataobj.getPassword())) {
						try {
							String encAdhNo=null;
							if(propertyPath.getFunctionExecute().equals("1"))
							{
								encAdhNo = cipherAesDemo.encryptHsnData(StoreDataobj.aadharno);
							}
							else if(propertyPath.getFunctionExecute().equals("2"))
							{
								encAdhNo =cipherAesDemo.encryptBlowFish(StoreDataobj.aadharno);
							}
							
							String partionID=StoreDataobj.aadharno.substring(11);
							refno1 = db.retrieveUid(encAdhNo);
							if ((refno1 == null || refno1 == "")) {
								db.updateDashBoard(StoreReqobj.getUSERID());
								msg = "Inserted  User from Web Service";
								uuid = db.retrieveSequence()+partionID;
								refno1 = uuid;
								db.insertTblVault(ValidateUserRespres[4], StoreReqobj.getUSERID(),
										ipAdd, encAdhNo, uuid,partionID);
								sessionKey = aesCipher.generateSessionKey();
								SimpleDateFormat df = new SimpleDateFormat("YYYY-MM-dd'T'HH:mm:ss");
								String ts = df.format(new Date());
								strResp.refno = refno1;
								strResp.ts = ts;
								auth.ts = ts;
								SKEY skey = new SKEY();
								StringWriter sw = new StringWriter();
								JAXBContext context = JAXBContext.newInstance(STRRESP.class);
								Marshaller m = context.createMarshaller();
								m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
								m.marshal(strResp, sw);
								String xmlString = sw.toString();
								byte[] inputData = xmlString.getBytes();
								new String(inputData);
								ADHSTRRESPobj.data = getData(sessionKey, ts, inputData);
								ADHSTRRESPobj.auth = auth;
								byte[] srcHash = aesCipher.generateHash(inputData);
								byte[] iv = aesCipher.generateIv(ts);
								byte[] aad = aesCipher.generateAad(ts);
								byte[] encSrcHash = aesCipher.encryptDecryptUsingSessionKey(true, sessionKey, iv, aad,srcHash);
								java.security.interfaces.RSAPublicKey publicKey = rsa
										.getPublicKey(CertPath + propertyPath.getPublicCertificateName());
								String sessionKeyenc = rsa.encrypt1(sessionKey, publicKey);
								RSAPrivateKey privateKey = rsa.getPrivateKey(ClientCertPath + "SWIFTDBVAULTPUBkey.pem");
								rsa.decrypt1(sessionKeyenc, privateKey);
								skey.innerText = sessionKeyenc;
								skey.ci = "22-12-2020";
								HMAC hmac = new HMAC();
								hmac.innerText = Base64.encodeBase64String(encSrcHash);// AESCipher.byteArrayToHexString(encSrcHash);
								ADHSTRRESPobj.hmac = hmac;
								ADHSTRRESPobj.skey = skey;
								ADHSTRRESPobj.retcode = "00";
								ADHSTRRESPobj.retm = "SUCCESS";
							} else {
								uuid = refno1 + " " + "Aadhar Number already exists in the vault";
								msg = "Duplicate store request from web service";
								sessionKey = aesCipher.generateSessionKey();// takes too much time
								SimpleDateFormat df = new SimpleDateFormat("YYYY-MM-dd'T'HH:mm:ss");
								String ts = df.format(new Date());// aesCipher.getCurrentISOTimeInUTF8();
								STRRESP strResp = new STRRESP();
								strResp.refno = refno1;
								strResp.ts = ts;
								auth.ts = ts;
								SKEY skey = new SKEY();
								StringWriter sw = new StringWriter();
								JAXBContext context = JAXBContext.newInstance(STRRESP.class);
								Marshaller m = context.createMarshaller();
								m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
								m.marshal(strResp, sw);
								String xmlString = sw.toString();
								byte[] inputData = xmlString.getBytes();
								ADHSTRRESPobj.data = getData(sessionKey, ts, inputData);
								ADHSTRRESPobj.auth = auth;
								ADHSTRRESPobj.retcode = "01";
								byte[] srcHash = aesCipher.generateHash(inputData);
								//System.out.println(" srcHash before encryption :" + new String(srcHash));
								byte[] iv = aesCipher.generateIv(ts);
								byte[] aad = aesCipher.generateAad(ts);
								byte[] encSrcHash = aesCipher.encryptDecryptUsingSessionKey(true, sessionKey, iv, aad,
										srcHash);
								java.security.interfaces.RSAPublicKey publicKey = rsa
										.getPublicKey(CertPath +propertyPath.getPublicCertificateName());// public key
								String sessionKeyenc = rsa.encrypt1(sessionKey, publicKey);
								skey.innerText = sessionKeyenc;
								skey.ci = "22-12-2020";
								HMAC hmac = new HMAC();
								hmac.innerText = Base64.encodeBase64String(encSrcHash);// AESCipher.byteArrayToHexString(encSrcHash);
								ADHSTRRESPobj.hmac = hmac;
								ADHSTRRESPobj.skey = skey;
								ADHSTRRESPobj.retm = "Duplicate store request from web service";
							}
						} catch (Exception e) {
							e.printStackTrace();
							ADHSTRRESPobj.retcode = "98";
							ADHSTRRESPobj.retm = "FAIL";
						}
					} else {
						ADHSTRRESPobj.retcode = "13";
						ADHSTRRESPobj.retm = "FAIL";
					}
				} else {
					ADHSTRRESPobj.retcode = "08";
					ADHSTRRESPobj.retm = "FAIL";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			ADHSTRRESPobj.retcode = "98";
			ADHSTRRESPobj.retm = "FAIL";
		}
		if (ADHSTRRESPobj.retcode.equalsIgnoreCase("00") || ADHSTRRESPobj.retcode.equalsIgnoreCase("01")) {
			db.insertActivityLog(StoreReqobj.getUSERID(), ValidateUserRespres[4], time, ipAdd, msg, refno1.toString(),
					StoreDataobj.getAPPUSER().toString(), StoreReqobj.getTXN().toString(),
					ADHSTRRESPobj.retcode.toString(), ADHSTRRESPobj.retm.toString());
		} else {
			db.insertActivityLog(StoreReqobj.getUSERID(), ValidateUserRespres[4], time, ipAdd, msg, refno1.toString(),
					StoreDataobj.getAPPUSER().toString(), StoreReqobj.getTXN().toString(),
					ADHSTRRESPobj.retcode.toString(), ADHSTRRESPobj.retm.toString());
		}
		return ADHSTRRESPobj;
	}
	
	private void retrieveAAdharData() {
		propertyPath.getCertPath();
	}

	public String RemoveNull(String Val){
		String Res = " ";
		if (Val == null) {
			
			Res = " ";
		} else {
			Res = Val;
		}
		return Res;
	}
	
	public StoreReq ParseStoreReq(String data) {
		try {
			DocumentBuilder dbp = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(data));
			Document doc = dbp.parse(is);
			doc.getDocumentElement().normalize();
			NodeList nList = null;
			nList = doc.getElementsByTagName("auth");
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					StoreReqobj.setUSERID(eElement.getAttribute("userid"));
					StoreReqobj.setLK(eElement.getAttribute("lk"));
					StoreReqobj.setTXN(eElement.getAttribute("txn"));
					StoreReqobj.setVersion(eElement.getAttribute("ver"));
					StoreReqobj.setTS(eElement.getAttribute("ts"));
				}
			}
			NodeList nList1 = null;
			StoreReqobj.setDATA(doc.getElementsByTagName("data").item(0).getTextContent());
			StoreReqobj.setHMAC(doc.getElementsByTagName("hmac").item(0).getTextContent());
			StoreReqobj.setSKEY(doc.getElementsByTagName("skey").item(0).getTextContent());
			nList1 = doc.getElementsByTagName("skey");
			for (int temp = 0; temp < nList1.getLength(); temp++) {
				Node nNode = nList1.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					StoreReqobj.setCi(eElement.getAttribute("ci"));
				}
			}
			StoreReqobj.status = "Y";
		} catch (Exception e) {
			e.printStackTrace();
			StoreReqobj.status = "N";
		}
		return StoreReqobj;
	}
	
	
	public String ValidateUser(String userid, String LK, String RemoteIP) {
		String Status = null;

		try {
			AppUser appUser = db.validateUserData(userid, LK, RemoteIP);
			Status = appUser.getUser_Status();

			//System.out.println("Status is" + Status);

		} catch (Exception e) {
			e.printStackTrace();
			Status = "04~";
			
		}

		return Status;

	}
	public StoreData ParseDATAReq(String data)
	{
		//System.out.println("Actual data after decryption : " +data);
		//data hardcoded for testing purpose only
	//	data="<ADHDATA xmlns='http://www.miscot.com/SWIFTDBVAULT/1.0'><STORE TS='20180315115455481'><PASSWORD>abcdfg</PASSWORD><AADHARNO>123456789012</AADHARNO><APPUSER>GIRISH</APPUSER></STORE></ADHDATA>";
		//System.out.println("after removed xsd data :"+data);
		//StoreData StoreDataobj = new StoreData();
		try 
		{
		DocumentBuilder dbp = DocumentBuilderFactory.newInstance().newDocumentBuilder();
	    InputSource is = new InputSource();
	    is.setCharacterStream(new StringReader(data));
	    Document doc = dbp.parse(is);
		doc.getDocumentElement().normalize();
		 NodeList nList=null;
		 
			  nList = doc.getElementsByTagName("store");
		
		 
		 
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) 
				{
					Element eElement = (Element) nNode;
					
					StoreDataobj.setTS(eElement.getAttribute("ts"));
				
				}		
			}


	StoreDataobj.setPassword(doc.getElementsByTagName("password").item(0).getTextContent());
	StoreDataobj.setAadharno(doc.getElementsByTagName("aadharno").item(0).getTextContent());
	StoreDataobj.setAPPUSER(doc.getElementsByTagName("appuser").item(0).getTextContent());	

			
			StoreDataobj.status="Y";
		} catch (Exception e) {
			e.printStackTrace();
			StoreDataobj.status="N";
		}
		
		return StoreDataobj;
	}
	
	public RetrievalData ParseRetriavalDATAReq(String data)
	{
		//System.out.println("Actual data after decryption : " +data);
		//data hardcoded for testing purpose only
	//	<RTREQ ts="20180315115455481"><PASSWORD>ABC</PASSWORD><REFNO>0001102</REFNO><REFTYPE>A</REFTYPE><APPUSER>20001</APPUSER></RTREQ>

		//data="<RTREQ TS='20180315115455481'><PASSWORD>ABC</PASSWORD><REQREF>0001102</REQREF><REFTYPE>R</REFTYPE><APPUSER>20001</APPUSER></RTREQ>";
		//data="<RTREQ TS='20180315115455481'><PASSWORD>ABC</PASSWORD><AADHARNO>1234567891012</AADHARNO><REFTYPE>A</REFTYPE><APPUSER>20001</APPUSER></RTREQ>";
		
		//System.out.println("after removed xsd data :"+data);
		
		try 
		{
		DocumentBuilder dbp = DocumentBuilderFactory.newInstance().newDocumentBuilder();
	    InputSource is = new InputSource();
	    is.setCharacterStream(new StringReader(data));
	    Document doc = dbp.parse(is);
		doc.getDocumentElement().normalize();
		  NodeList nList = doc.getElementsByTagName("rtreq");
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) 
				{
					Element eElement = (Element) nNode;
					
					RetrieveDataObj.setTS(eElement.getAttribute("ts"));
				
				}		
			}
			RetrieveDataObj.setREFTYPE(doc.getElementsByTagName("reftype").item(0).getTextContent());
			if(doc.getElementsByTagName("reftype").item(0).getTextContent().equalsIgnoreCase("A")){
				RetrieveDataObj.setAadharno(doc.getElementsByTagName("reqref").item(0).getTextContent());
			}else{
				RetrieveDataObj.setREQREF(doc.getElementsByTagName("reqref").item(0).getTextContent());
			}
			RetrieveDataObj.setPassword(doc.getElementsByTagName("password").item(0).getTextContent());
			
			RetrieveDataObj.setAPPUSER(doc.getElementsByTagName("appuser").item(0).getTextContent());
			RetrieveDataObj.Status="Y";
			//System.out.println("RetrieveDataObj.REFTYPE============"+RetrieveDataObj.REFTYPE);
		} catch (Exception e) {
			e.printStackTrace();
			RetrieveDataObj.Status="N";
		}
		
		return RetrieveDataObj;
	}

	public DATA getData(byte[] SessionKey,String TS, byte[] inputData) throws IllegalStateException, InvalidCipherTextException, Exception
	{
		DATA data=new DATA();
	    
		System.out.println("data for encryption in getData :"+new String(inputData));
		////System.out.println("actual value :"+Base64.encodeBase64String(inputData));
       ////System.out.println("TS for encrypt data :"+new String(TS));
		
		//AESCipher aesCipher;
		
		//aesCipher = new AESCipher();
		
	    byte[] cipherTextWithTS = aesCipher.encrypt(inputData, SessionKey, TS);
	        
		data.innerText=   Base64.encodeBase64String(cipherTextWithTS); //AESCipher.byteArrayToHexString(cipherTextWithTS);
		
		// //System.out.println("after encryption using encodeBase64String innerText :"+data.innerText.toString());
			
		 aesCipher.byteArrayToHexString(cipherTextWithTS);
		
		return data;
	}

	
	//For retrival Request
	//For retrival Request
		public ADHRTRESP retriveAdhData(String data, String ipAdd)throws Exception {
			String time = null;
			//ADHSTRRESP ADHSTRRESPobj=new ADHSTRRESP();
			ADHRTRRESPobj.retcode="00";
			 StoreReqobj=ParseStoreReq(data);
			
			
			 //auth=null;
			 String ClientCertPath=propertyPath.getClientCertificateName();
			String rEQREF=null;
		    String ValidateUserResp =null;
		    String decTxt=null;
		    String msg = "";
		    byte[] sessionKey=null;
		    //RetrieveDataObj=null;
		    String ValidateUserRespres[]=null;
		   // DBUtil db = null;
		   //ADHSTRRESPobj=null;
		
		    try
		    {
		    	 
		    	 //ADHSTRRESPobj.retcode="00";
					//StoreReqobj = ParseStoreReq(data);
		    	//System.out.println("Before propertyPath"+propertyPath);
				String CertPath = propertyPath.getCertPath();
				//System.out.println("After propertyPath"+propertyPath);
				//System.out.println("CertPath"+CertPath);
				
				
					//System.out.println("StoreReqobj"+StoreReqobj.Status);
					
			  time = new SimpleDateFormat("hh:mm:ss aa").format(new Date());
			
			DateFormat dateFormat = new SimpleDateFormat("dd-MMM-YYYY");
			Date dateUpdated = new Date();
			dateFormat.format(dateUpdated);
			if (StoreReqobj.getStatus().equalsIgnoreCase("Y"))
			{
				ValidateUserResp=ValidateUser(StoreReqobj.userid,StoreReqobj.lk,ipAdd);
				 ValidateUserRespres=ValidateUserResp.split("~");
				if ( ValidateUserRespres[0].equalsIgnoreCase("00")){
			
					 //auth= new AUTH();
					 auth.lk=StoreReqobj.lk ;
					 auth.txn=StoreReqobj.txn;
					 auth.userid=StoreReqobj.userid;
					 auth.version=StoreReqobj.ver;  
					 
			    	RSAPrivateKey privateKey=rsa.getPrivateKey(ClientCertPath + ValidateUserRespres[1]+".pem"); // for decrypt the data request coming from client this is dbvault pvt key
			    	try
			    	{
			    		 sessionKey=rsa.decrypt1(StoreReqobj.skey, privateKey);
			    		 //System.out.println("sessionKey decrypted for client request:"+sessionKey);
			    		 
			    		 String sessionKeyACtual= new String(sessionKey);//
			    		 //System.out.println("actual value sessionKeyACtual:"+sessionKeyACtual);
			    		
			    	}catch (Exception e) {
						e.printStackTrace();
						ADHRTRRESPobj.retcode="11";
						ADHRTRRESPobj.retm="FAIL";
					} 	
			    	try
			    	{
			    		 decTxt=aesCipher.getDecrypted(Base64.decodeBase64(StoreReqobj.data),sessionKey,Base64.decodeBase64(StoreReqobj.hmac));
			    		 System.out.println("decTxt::"+decTxt);
					}
			    	catch (Exception e) {
						e.printStackTrace();
						ADHRTRRESPobj.retcode="12";
						ADHRTRRESPobj.retm="FAIL";
					}
				}
				else
				{
					ADHRTRRESPobj.retcode=ValidateUserRespres[0];
					ADHRTRRESPobj.retm="FAIL"; 
				}
			}
			else
			{
				ADHRTRRESPobj.retcode="100";
				ADHRTRRESPobj.retm="FAIL";
			}
			if (ADHRTRRESPobj.retcode.equalsIgnoreCase("00"))
			{
				RetrieveDataObj =  ParseRetriavalDATAReq(decTxt);
				if (RetrieveDataObj.getStatus().equalsIgnoreCase("Y"))
				{
					try {		
						
					String Adhar_no=null;
			       	 rEQREF =RetrieveDataObj.REQREF;
			       	 //System.out.println("rEQREF"+rEQREF);
					/*String decrEQREF =EncryptionDecryption.decrypt(retrievalData.REQREF);
					String decAdhNo =EncryptionDecryption.decrypt(retrievalData.Aadharno);*/
					
					//if(s[2].equalsIgnoreCase("adhNo")){
						//System.out.print("retrievalData.REFTYPE"+RetrieveDataObj.REFTYPE);
						if(RetrieveDataObj.REFTYPE.equalsIgnoreCase("A")){
							//String encAdhNo =EncryptionDecryption.encrypt(retrievalData.Aadharno);
							
							//DigitalSigner DigS = new DigitalSigner();
							//System.out.println("Calling CipherAESDemo==========="+RetrieveDataObj.Aadharno);
							String encAdhNo=null;
							//System.out.println("Exceute Function"+propertyPath.getFunctionExecute());
							if(propertyPath.getFunctionExecute().equals("1"))
							{
								encAdhNo = cipherAesDemo.encryptHsnData(RetrieveDataObj.Aadharno);
							}
							else if(propertyPath.getFunctionExecute().equals("2"))
							{
								encAdhNo =cipherAesDemo.encryptBlowFish(RetrieveDataObj.Aadharno);
							}
							//String encAdhNo=cipherAesDemo.encryptHsnData(RetrieveDataObj.Aadharno);
							
							//By BlowFish
							//String encAdhNo=cipherAesDemo.encryptBlowFish(RetrieveDataObj.Aadharno);
							//String sqlquery=" union select EKYC_REFNO as uuid from tbl_aadharhsn1 where ENCRYPTED_AADHAR_NO='NrW+O+ot+2kp+metFrNUcA=='";
							//rEQREF=db.GetValue("select uuid from tbl_vault where encAdhNo='"+ encAdhNo +"' ");//+ sqlquery);
							rEQREF=db.retrieveUid(encAdhNo);
							//System.out.println("rEQREF:::"+rEQREF);
							if(rEQREF != null && rEQREF!="") {
								msg="Search Refrence No From Web Service";
							    sessionKey = aesCipher.generateSessionKey();
							    //System.out.println("original value of session key for encrypting response :"+Base64.encodeBase64String(sessionKey));
						        //String ts ="20180315115455481";   //aesCipher.getCurrentISOTimeInUTF8(); //if encrypted and decrypted ts not same throw error :org.bouncycastle.crypto.InvalidCipherTextException: mac check in GCM failed 
						       
						        SimpleDateFormat df = new SimpleDateFormat("YYYY-MM-dd'T'HH:mm:ss"); 
						  		String ts = df.format(new Date());
						        
						    //    String encRefresponse = EncryptionDecryption.encrypt(refno1); no need of encrytion again
								rtrResp.setREFNO(rEQREF);
								rtrResp.setTS(ts);
								rtrResp.setREFTYPE("R");
								auth.ts=ts;
								SKEY skey=new SKEY();
								StringWriter sw = new StringWriter();
								JAXBContext context = JAXBContext.newInstance(RTRRESP.class);
						        Marshaller m = context.createMarshaller();
						        //for pretty-print XML in JAXB
						        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
						        m.marshal(rtrResp, sw);
						   		String xmlString = sw.toString();	
						   	    byte[] inputData = xmlString.getBytes();
						   	    String is1= new String(inputData);
						   	    //System.out.println("response inputData xml: "+is1);
						   	    ADHRTRRESPobj.data=getData(sessionKey, ts, inputData);
						   		ADHRTRRESPobj.auth=auth;				   	   
						   	    byte[] srcHash = aesCipher.generateHash(inputData);
						   	    //System.out.println(" srcHash before encryption :"+new String(srcHash));
						   	    byte[] iv = aesCipher.generateIv(ts);
						        byte[] aad = aesCipher.generateAad(ts);
						        byte[] encSrcHash = aesCipher.encryptDecryptUsingSessionKey(true, sessionKey, iv, aad, srcHash);
						        //System.out.println(" encSrcHash :"+new String(encSrcHash));
						    	java.security.interfaces.RSAPublicKey publicKey=rsa.getPublicKey(CertPath+propertyPath.getPublicCertificateName());//public key
						    	String sessionKeyenc=rsa.encrypt1(sessionKey, publicKey);
						    	skey.innerText=sessionKeyenc;
						    	skey.ci="22-12-2020";
								HMAC hmac=new HMAC();
								hmac.innerText=Base64.encodeBase64String(encSrcHash);//    AESCipher.byteArrayToHexString(encSrcHash);
								ADHRTRRESPobj.hmac=hmac;
								ADHRTRRESPobj.skey=skey;
								ADHRTRRESPobj.retcode="00";
								ADHRTRRESPobj.retm="SUCCESS";
								
							}
							else {
								ADHRTRRESPobj.retcode="16";
								ADHRTRRESPobj.retm="FAIL";
								msg="Aadhar No :"+RetrieveDataObj.Aadharno +" does not exists";
								rEQREF="";
							}
								
						}else if(RetrieveDataObj.REFTYPE.equalsIgnoreCase("R")){
							//String sqlquery=" union select ENCRYPTED_AADHAR_NO as encAdhNo from tbl_aadharhsn1 where EKYC_REFNO='"+ retrievalData.REQREF +"'";
							
							Adhar_no=db.retreieveAadhar(RetrieveDataObj.REQREF);
							//System.out.println("Adhar_no===="+Adhar_no);
	                        if(Adhar_no != null && Adhar_no!="") {
	                        msg="Search Aadhar No From Web Service";
						    sessionKey = aesCipher.generateSessionKey();
						    //System.out.println("original value of session key for encrypting response :"+Base64.encodeBase64String(sessionKey));
					       // String ts ="20180315115455481"; 
						    SimpleDateFormat df = new SimpleDateFormat("YYYY-MM-dd'T'HH:mm:ss"); 
					  		String ts = df.format(new Date());
						    //aesCipher.getCurrentISOTimeInUTF8(); //if encrypted and decrypted ts not same throw error :org.bouncycastle.crypto.InvalidCipherTextException: mac check in GCM failed 
					        //RTRRESP strResp= new RTRRESP();
					       // String decADHResponse = EncryptionDecryption.decrypt(Adhar_no);
					        //System.out.println("Adhar_no-----------cipherText" + Adhar_no);
					        byte[] output = new BASE64Decoder().decodeBuffer(Adhar_no);
							//DigitalSigner DigS = new DigitalSigner();
					        //System.out.println("Exceute Function"+propertyPath.getFunctionExecute());
					        String decADHResponse=null;
							if(propertyPath.getFunctionExecute().equals("1"))
							{
								decADHResponse = cipherAesDemo.decryptHsnData(output);
							}
							else if(propertyPath.getFunctionExecute().equals("2"))
							{
								decADHResponse =cipherAesDemo.decryptBlowFish(Adhar_no);
							}
							//String decADHResponse=cipherAesDemo.decryptHsnData(output);//No need to encrypt again
					        //String decADHResponse=cipherAesDemo.decryptBlowFish(Adhar_no);
							rtrResp.setAADHARNO(decADHResponse);
							rtrResp.setTS(ts);
							rtrResp.setREFTYPE("A");
							auth.ts=ts;
							SKEY skey=new SKEY();
							StringWriter sw = new StringWriter();
							JAXBContext context = JAXBContext.newInstance(RTRRESP.class);
					        Marshaller m = context.createMarshaller();
					        //for pretty-print XML in JAXB
					        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
					        m.marshal(rtrResp, sw);
					   		String xmlString = sw.toString();	
					   	    byte[] inputData = xmlString.getBytes();
					   	    String is1= new String(inputData);
					   	    //System.out.println("response inputData xml: "+is1);
					   	    ADHRTRRESPobj.data=getData(sessionKey, ts, inputData);
					   	 	ADHRTRRESPobj.auth=auth;
					   	    byte[] srcHash = aesCipher.generateHash(inputData);
					   	    //System.out.println(" srcHash before encryption :"+new String(srcHash));
					   	    byte[] iv = aesCipher.generateIv(ts);
					        byte[] aad = aesCipher.generateAad(ts);
					        byte[] encSrcHash = aesCipher.encryptDecryptUsingSessionKey(true, sessionKey, iv, aad, srcHash);
					        //System.out.println(" encSrcHash :"+new String(encSrcHash));
					    	java.security.interfaces.RSAPublicKey publicKey=rsa.getPublicKey(CertPath +propertyPath.getPublicCertificateName());//public key
					    	String sessionKeyenc=rsa.encrypt1(sessionKey, publicKey);
					    	skey.innerText=sessionKeyenc;
					    	skey.ci="22-12-2020";
							HMAC hmac=new HMAC();
							hmac.innerText=Base64.encodeBase64String(encSrcHash);//    AESCipher.byteArrayToHexString(encSrcHash);
							ADHRTRRESPobj.hmac=hmac;
							ADHRTRRESPobj.skey=skey;
	                        }else{
	                        	ADHRTRRESPobj.retcode="16";
	                        	ADHRTRRESPobj.retm="FAIL";
								msg="Reference No :"+RetrieveDataObj.REQREF +" does not exists";
								rEQREF="";
	                        }
						} 
						
						
						
						} catch (Exception e) {
							//System.out.println("Exception 98 :"+e.getMessage());
								e.printStackTrace();
								ADHRTRRESPobj.retcode="98";
								ADHRTRRESPobj.retm="FAIL";
							}
					
				}
				else
				{
					ADHRTRRESPobj.retcode="08";
					ADHRTRRESPobj.retm="FAIL";
				}
			}	
		    
		} catch (Exception e) {
			//System.out.println("Exception 98 :"+e.getMessage());
				e.printStackTrace();
				ADHRTRRESPobj.retcode="98";
				ADHRTRRESPobj.retm="FAIL";
			}
		    
		    //System.out.println("StoreReqobj.getUSERID() :"+StoreReqobj.getUSERID());
		    //System.out.println("ValidateUserRespres[4]  :"+ValidateUserRespres[4] );
		   //System.out.println("retrievalData.getAPPUSER() :"+RetrieveDataObj.getAPPUSER());
		    //System.out.println("StoreReqobj.getTXN() :"+StoreReqobj.getTXN());
		    //System.out.println("ADHSTRRESPobj.retcode :"+ADHSTRRESPobj.retcode);
		    
		    //System.out.println("ADHSTRRESPobj.retm :"+ADHSTRRESPobj.retm);
		    
			/*String	sql="INSERT INTO ActivityLog(USER_ID,APPNAME,DATE_D,TIME_T,IP_ADDRESS,TASK_PERFORMED,DESCPTION,uuid,app_user,txn,Error_code,Error_Rem)     " +
					"VALUES('"+StoreReqobj.getUSERID()+"','"+ ValidateUserRespres[4] +"',sysdate,'"+time+"','"+ipAdd+"','Search','"+ msg +"','"+rEQREF+"','"+RemoveNull(RetrieveDataObj.getAPPUSER())+"','"+StoreReqobj.getTXN()+"','"+ADHSTRRESPobj.retcode+"','"+ADHSTRRESPobj.retm+"')";*/
			db.searchInsertActivityLog(StoreReqobj.getUSERID(),ValidateUserRespres[4],time,ipAdd,msg,rEQREF,RetrieveDataObj.getAPPUSER(),StoreReqobj.getTXN(),ADHRTRRESPobj.retcode,ADHRTRRESPobj.retm);
			//db.Qexecute(sql);
			/*sql="update tbl_dashboard set FIELD_VALUE = FIELD_VALUE + 1 where CHART_ID = 3  and FIELD_NAME='"+StoreReqobj.getUSERID()+"'";	*/
			db.retrieveUpdateAadhar(StoreReqobj.getUSERID());
			////System.out.println("sql" + sql);
			//db.Qexecute(sql);
		
			
			
			
			return ADHRTRRESPobj;
		}

		
		

		
		
		
	
}
