package com.miscot.springmvc.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SignatureException;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;

public interface RSAInterface {

	String getKey(String filename) throws IOException, GeneralSecurityException;
	RSAPrivateKey getPrivateKey(String filename) throws IOException, GeneralSecurityException;
	RSAPrivateKey getPrivateKeyFromString(String key) throws IOException, GeneralSecurityException;
	RSAPublicKey getPublicKey(String filename) throws IOException, GeneralSecurityException;
	RSAPublicKey getPublicKeyFromString(String key) throws IOException, GeneralSecurityException;
	String sign(PrivateKey privateKey, String message) throws NoSuchAlgorithmException, InvalidKeyException, SignatureException, UnsupportedEncodingException;
	boolean verify(PublicKey publicKey, String message, String signature) throws SignatureException, NoSuchAlgorithmException, UnsupportedEncodingException, InvalidKeyException;
	String encrypt(String rawText, PublicKey publicKey) throws IOException, GeneralSecurityException;
	String encrypt1(byte[] rawText, PublicKey publicKey) throws IOException, GeneralSecurityException;
	String decrypt(String cipherText, PrivateKey privateKey) throws IOException, GeneralSecurityException;
	byte[] decrypt1(String cipherText, PrivateKey privateKey) throws IOException, GeneralSecurityException;
	byte[] decrypt2(String cipherText, PrivateKey privateKey) throws IOException, GeneralSecurityException;
	byte[] fromHexString(String s);
}
