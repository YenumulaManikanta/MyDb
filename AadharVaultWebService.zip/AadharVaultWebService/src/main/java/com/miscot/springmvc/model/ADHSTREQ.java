package com.miscot.springmvc.model;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;
@Component
@XmlRootElement(name="adhstreq")
@XmlAccessorType(XmlAccessType.FIELD)
public class ADHSTREQ {
	  public AUTH auth;
	  public DATA data;
	  public SKEY skey;
	  public HMAC hmac;

}
