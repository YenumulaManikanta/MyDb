package com.miscot.springmvc.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.miscot.springmvc.configuration.PropertiesPath;
import com.miscot.springmvc.model.ADHRTRESP;
import com.miscot.springmvc.model.ADHSTRRESP;

import com.miscot.springmvc.service.ProcessReqXML;

@Controller
public class DBVaultRestController {
	@Autowired	
	PropertiesPath propertyPath;
	@Autowired
	ProcessReqXML prx;
	@Autowired
	ADHSTRRESP ADHSTRRESPobj;
	@Autowired
	ADHRTRESP ADHRTRESPobj;
	
	@RequestMapping(value = "/StoreAdhVaultRequest", method = RequestMethod.POST)
	public @ResponseBody ADHSTRRESP storeAadhar(@RequestBody String reqXML, HttpServletRequest request) {
		String output = reqXML;
		ADHSTRRESPobj=null;
    	String ipAdd=propertyPath.getIpAddress();
		try {
			ADHSTRRESPobj = prx.StoreAadhar(output,ipAdd);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ADHSTRRESPobj;
	}
	
	@RequestMapping(value = "/ChecktRequest", method = RequestMethod.GET)
	public @ResponseBody String test( HttpServletRequest request) {
		 
		ADHSTRRESPobj=null;
    	String ipAdd=propertyPath.getIpAddress();
		 
		return ipAdd;
	}
	
	@RequestMapping(value = "/RetrieveAdhVaultRequest", method = RequestMethod.POST)
	public @ResponseBody ADHRTRESP retrieveAadhar(@RequestBody String reqXML, HttpServletRequest request) {
		System.out.println("reqXML::::::::::::"+reqXML);
		String output = reqXML;
		String ipAdd=propertyPath.getIpAddress();
		ADHRTRESPobj = null;
		try {
			ADHRTRESPobj = prx.retriveAdhData(output,ipAdd);
		} catch (Exception e) {
			e.printStackTrace();
		}
   	return ADHRTRESPobj;
	}
}