package com.miscot.springmvc.service;

public interface CipherAESDemoInterface {
	//String encryptHsnData_1(String adhar_no) throws Exception;
	//String decryptHsnData_1(byte[] encryptedBytes) throws Exception;
	String encryptHsnData(String adhar_no) throws Exception;
	String decryptHsnData(byte[] encryptedBytes) throws Exception;
	String encryptHsnData1(String adhar_no) throws Exception;
	String decryptHsnData1(byte[] encryptedBytes) throws Exception;
	 String encryptBlowFish(String strClearText) throws Exception;
	String decryptBlowFish(String strEncrypted) throws Exception;
}
